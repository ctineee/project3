import * as THREE from "https://cdn.skypack.dev/three@0.129.0/build/three.module.js";
import { OrbitControls } from "https://cdn.skypack.dev/three@0.129.0/examples/jsm/controls/OrbitControls.js";
import { GLTFLoader } from "https://cdn.skypack.dev/three@0.129.0/examples/jsm/loaders/GLTFLoader.js";

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);

let mouseX = window.innerWidth / 2;
let mouseY = window.innerHeight / 2;

let object;
let objToRender = 'eye';

const loader = new GLTFLoader();
const textureLoader = new THREE.TextureLoader();  // Texture loader

const meshTextureMappings = {};
let currentPicture = 1;
const pictureCount = 8;  // Total number of pictures

// Setting up mesh to texture mappings
// for (let i = 0; i < 207; i++) {  // For Cube002 to Cube208
//     let cubeName = `Cube${(i + 2).toString().padStart(3, '0')}`;
//     meshTextureMappings[cubeName] = textureLoader.load(`http://127.0.0.1:5500/Desktop/CodeProject3/pic/pic${currentPicture}.jpg`);
//     currentPicture = (currentPicture % pictureCount) + 1;
// }
// meshTextureMappings['Plane_0'] = textureLoader.load(`/Desktop/CodeProject3/pic/pic${currentPicture}.jpg`);  // For Plane_0

// let cubeName = 'Cube002';
// meshTextureMappings[cubeName] = textureLoader.load('.Users/sarah/Downloads/pic/pic1.jpg');

loader.load(
`models/${objToRender}/head1.gltf`,
  function (gltf) {
    object = gltf.scene;
    object.scale.set(100, 100, 100);
    object.position.y = 50;

    // Apply textures to meshes
    object.traverse(function (child) {
      if (child.isMesh) {
        console.log('Mesh Name:', child.name);  // Log the name of the mesh
        if (meshTextureMappings[child.name]) {
          child.material.map = meshTextureMappings[child.name];
          child.material.needsUpdate = true;
        }
      }
    });

    scene.add(object);
  },
  function (xhr) {
    console.log((xhr.loaded / xhr.total * 100) + '% loaded');
  },
  function (error) {
    console.error('An error occurred during the loading process:', error);
  }
);

const renderer = new THREE.WebGLRenderer({ alpha: true });
renderer.setSize(window.innerWidth, window.innerHeight);
document.getElementById("container3D").appendChild(renderer.domElement);

camera.position.z = objToRender === "dino" ? 25 : 500;

const directionalLight = new THREE.DirectionalLight(0xffffff, 1.5);
directionalLight.position.set(0, 500, 0);
scene.add(directionalLight);

const frontLight = new THREE.DirectionalLight(0xffffff, 0.5);
frontLight.position.set(0, 0, 500);
scene.add(frontLight);

const topLight = new THREE.DirectionalLight(0xffffff, 1);
topLight.position.set(500, 500, 500);
topLight.castShadow = true;
scene.add(topLight);

const ambientLight = new THREE.AmbientLight(0x333333, objToRender === "dino" ? 5 : 1);
scene.add(ambientLight);

let controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.05;
controls.rotateSpeed = 0.1;
controls.minDistance = 100;
controls.maxDistance = 500;

function animate() {
    requestAnimationFrame(animate);
    controls.update();
    renderer.render(scene, camera);
}

window.addEventListener("resize", function () {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
});

animate();
